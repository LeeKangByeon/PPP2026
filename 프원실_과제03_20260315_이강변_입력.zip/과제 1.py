1.
C = int(input())
F= C * 1.8 + 32
print(F)

2.
import math
W = int(input("자신의 몸무게를 입력하시오"))
H = int(input("자신의 키를 입력하시오"))
BMI = W / H ** 2
print(BMI)

3.
import math
r = int(input())
result = math.pi * r ** 2
print(result)

4.
A = int(input("사다리꼴의 밑변 길이를 적으시오"))
B = int(input("사다리꼴의 윗변 길이를 적으시오"))
H = int(input("사다리꼴의 높이를 적으시오"))
result = (A +  B) * H / 2
print(result)

5.
import math
x1 = int(input())
x2 = int(input())
y1 = int(input())
y2 = int(input())
x1y1의길이 = math.sqrt((x2 - x1) **2 + (y2 - y1) ** 2)
print(x1y1의길이)

6.
한라봉 = 0.5
딸기 = 0.34
바나나 = 0.77
A = float(input("한라봉을 먹은 g을 입력하시오:"))
B = float(input("딸기를 먹은 g을 입력하시오:"))
C = float(input("바나나를 먹은 g을 입력하시오:"))
C_한라봉 = A * 한라봉
C_딸기 = B * 딸기
C_바나나 = C * 바나나
print(C_한라봉, C_딸기, C_바나나)